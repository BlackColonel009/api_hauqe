(async function () {
  "use strict";

  const api = await import("/static/js/core/api.js");
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  let user = null;
  let readiness = null;
  let catalog = { fields: [], count_resources: [] };
  let rules = [];
  let models = [];
  let selectedRule = null;
  let selectedModel = null;
  let selectedWeights = [];
  let completenessDraft = null;
  let publishTarget = null;
  let cloneSourceRule = null;
  let searchTimer = null;

  const fieldReqs = [];
  const countReqs = [];

  function e(v) {
    return String(v ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function icons() {
    window.lucide?.createIcons({ attrs: { "stroke-width": 1.8 } });
  }

  function has(code) {
    return Array.isArray(user?.permissions) && user.permissions.includes(code);
  }

  function state(message, error = false) {
    const node = $("#institutionalApiState");
    node.hidden = false;
    node.className = `dashboard-api-state ${error ? "error" : ""}`.trim();
    node.innerHTML = `
      <i data-lucide="${error ? "triangle-alert" : "info"}"></i>
      <div>
        <strong>${error ? "Opération impossible" : "Information"}</strong>
        <span>${e(message)}</span>
      </div>
    `;
    icons();
  }

  async function run(task, options = {}) {
    if (window.HAUQE_ACTION_LOADER) {
      return window.HAUQE_ACTION_LOADER.run(task, options);
    }
    return task();
  }

  function renderReadiness() {
    const cards = [
      ["clipboard-check", "COLLECTE_COMPLETUDE", readiness?.collecte_completude],
      ["building-2", "Classification entreprise", readiness?.classification_entreprise],
      ["badge-cent", "INFC", readiness?.infc],
    ];

    $("#institutionalReadiness").innerHTML = cards.map(([icon, label, item]) => `
      <article class="readiness-card ${item?.ready ? "ready" : "blocked"}">
        <span><i data-lucide="${icon}"></i></span>
        <div>
          <small>${e(label)}</small>
          <strong>${item?.version ? `v${e(item.version)}` : "Non publié"}</strong>
          <em>${e(item?.approval_reference || item?.calculation_mode || "Paramétrage requis")}</em>
        </div>
        <b>${item?.ready ? "PRÊT" : "BLOQUÉ"}</b>
      </article>
    `).join("");

    const active = readiness?.collecte_completude;
    $("#activeCompletenessStatus").textContent = active?.ready
      ? `Publiée · v${active.version}`
      : "Non publiée";
    $("#activeCompletenessStatus").className = `inst-status ${active?.ready ? "ready" : ""}`;
    icons();
  }

  async function loadReadiness() {
    readiness = await api.apiGet("/api/v1/governance/setup/readiness");
    renderReadiness();
  }

  async function loadCatalog() {
    catalog = await api.apiGet(
      "/api/v1/governance/setup/collecte-completeness/catalog"
    );
  }

  function fieldOptions(selected = []) {
    return catalog.fields.map((field) => `
      <option value="${e(field.name)}" ${selected.includes(field.name) ? "selected" : ""}>
        ${e(field.label)} · ${e(field.name)}
      </option>
    `).join("");
  }

  function countOptions(selected = "") {
    return catalog.count_resources.map((item) => `
      <option value="${e(item.code)}" ${item.code === selected ? "selected" : ""}>
        ${e(item.label)}
      </option>
    `).join("");
  }

  function renderRequirements() {
    $("#fieldRequirements").innerHTML = fieldReqs.length
      ? fieldReqs.map((item) => `
          <article class="requirement-row" data-field-id="${e(item.id)}">
            <label><span>Libellé</span><input data-field-prop="label" value="${e(item.label)}"></label>
            <label class="requirement-fields">
              <span>Champ(s)</span>
              <select data-field-prop="fields" multiple size="4">${fieldOptions(item.fields)}</select>
            </label>
            <label>
              <span>Condition</span>
              <select data-field-prop="match">
                <option value="ALL" ${item.match === "ALL" ? "selected" : ""}>Tous requis</option>
                <option value="ANY" ${item.match === "ANY" ? "selected" : ""}>Au moins un</option>
              </select>
            </label>
            <button class="remove-requirement" type="button" data-remove-field="${e(item.id)}"><i data-lucide="trash-2"></i></button>
          </article>
        `).join("")
      : `<div class="priority-empty compact">Aucune exigence de champ.</div>`;

    $("#countRequirements").innerHTML = countReqs.length
      ? countReqs.map((item) => `
          <article class="requirement-row count" data-count-id="${e(item.id)}">
            <label><span>Libellé</span><input data-count-prop="label" value="${e(item.label)}"></label>
            <label><span>Ressource</span><select data-count-prop="resource">${countOptions(item.resource)}</select></label>
            <label><span>Minimum</span><input data-count-prop="minimum" type="number" min="1" value="${e(item.minimum)}"></label>
            <button class="remove-requirement" type="button" data-remove-count="${e(item.id)}"><i data-lucide="trash-2"></i></button>
          </article>
        `).join("")
      : `<div class="priority-empty compact">Aucune exigence relationnelle.</div>`;

    $$("[data-field-prop]").forEach((node) => {
      node.onchange = () => {
        const row = node.closest("[data-field-id]");
        const item = fieldReqs.find((x) => x.id === row.dataset.fieldId);
        if (!item) return;
        const prop = node.dataset.fieldProp;
        item[prop] = prop === "fields"
          ? [...node.selectedOptions].map((option) => option.value)
          : node.value;
      };
    });

    $$("[data-count-prop]").forEach((node) => {
      node.onchange = () => {
        const row = node.closest("[data-count-id]");
        const item = countReqs.find((x) => x.id === row.dataset.countId);
        if (!item) return;
        item[node.dataset.countProp] = node.dataset.countProp === "minimum"
          ? Number(node.value)
          : node.value;
      };
    });

    $$("[data-remove-field]").forEach((button) => {
      button.onclick = () => {
        const index = fieldReqs.findIndex((x) => x.id === button.dataset.removeField);
        if (index >= 0) fieldReqs.splice(index, 1);
        renderRequirements();
      };
    });

    $$("[data-remove-count]").forEach((button) => {
      button.onclick = () => {
        const index = countReqs.findIndex((x) => x.id === button.dataset.removeCount);
        if (index >= 0) countReqs.splice(index, 1);
        renderRequirements();
      };
    });

    icons();
  }

  function completenessParams() {
    return {
      requirements: [
        ...fieldReqs.map((item) => ({
          type: "FIELD",
          label: item.label.trim() || item.fields.join(" / ") || "Champ obligatoire",
          fields: item.fields,
          match: item.match,
        })),
        ...countReqs.map((item) => ({
          type: "COUNT",
          label: item.label.trim() || item.resource,
          resource: item.resource,
          minimum: Number(item.minimum || 1),
        })),
      ],
      minimum_submission_rate: Number($("#completenessMinimum").value),
    };
  }

  function renderValidation(result) {
    $("#completenessValidationReport").innerHTML = `
      <div class="validation-summary ${result.valid ? "valid" : "invalid"}">
        <span><i data-lucide="${result.valid ? "circle-check-big" : "circle-x"}"></i></span>
        <div>
          <strong>${result.valid ? "Configuration valide" : "Configuration invalide"}</strong>
          <small>${result.valid ? "Prête à être enregistrée en brouillon." : "Corrigez les erreurs avant publication."}</small>
        </div>
      </div>
      ${result.errors?.length ? `<ul class="validation-errors">${result.errors.map((x) => `<li>${e(x)}</li>`).join("")}</ul>` : ""}
      ${result.warnings?.length ? `<ul class="validation-warnings">${result.warnings.map((x) => `<li>${e(x)}</li>`).join("")}</ul>` : ""}
      <details class="normalized-rule"><summary>Paramètres normalisés</summary><pre>${e(JSON.stringify(result.normalized, null, 2))}</pre></details>
    `;
    icons();
  }

  async function validateCompleteness() {
    try {
      const result = await api.apiPost(
        "/api/v1/governance/setup/collecte-completeness/validate",
        { parametres: completenessParams() }
      );
      renderValidation(result);
      return result;
    } catch (error) {
      state(error?.message || "Validation impossible.", true);
      return null;
    }
  }

  async function createCompletenessDraft() {
    const validation = await validateCompleteness();
    if (!validation?.valid) return;

    try {
      completenessDraft = await run(
        () => api.apiPost("/api/v1/governance/rules", {
          logical_code: "COLLECTE_COMPLETUDE",
          famille: $("#completenessFamily").value.trim() || null,
          libelle: $("#completenessLabel").value.trim(),
          description: $("#completenessDescription").value.trim() || null,
          version: $("#completenessVersion").value.trim(),
          parametres: validation.normalized,
          date_debut_effet: null,
        }),
        {
          button: $("#saveCompletenessDraft"),
          title: "COLLECTE_COMPLETUDE",
          message: "Création du brouillon",
        }
      );

      $("#publishCompleteness").hidden = false;
      state(`Brouillon ${completenessDraft.code} créé.`);
      await Promise.all([loadRules(), loadReadiness()]);
    } catch (error) {
      state(error?.message || "Création impossible.", true);
    }
  }

  function openPublish(kind, item) {
    publishTarget = { kind, item };
    $("#publishDialogTitle").textContent = kind === "rule"
      ? `Publier ${item.logical_code} v${item.version}`
      : `Publier ${item.code} v${item.version}`;
    $("#publishApprovalReference").value = "";
    $("#publishEffectiveDate").value = new Date().toISOString().slice(0, 10);
    $("#publishComment").value = "";
    $("#publishCommentField").hidden = kind === "model";
    $("#publishDialog").showModal();
    icons();
  }

  async function publish(event) {
    event.preventDefault();
    if (!publishTarget) return;

    try {
      if (publishTarget.kind === "rule") {
        await api.apiPost(
          `/api/v1/governance/rules/${publishTarget.item.id}/publish`,
          {
            reference_approbation: $("#publishApprovalReference").value.trim(),
            date_debut_effet: $("#publishEffectiveDate").value,
            commentaire: $("#publishComment").value.trim() || null,
          }
        );
      } else {
        await api.apiPost(
          `/api/v1/scoring/models/${publishTarget.item.id}/publish`,
          {
            reference_approbation: $("#publishApprovalReference").value.trim(),
            date_debut_validite: $("#publishEffectiveDate").value,
          }
        );
      }

      $("#publishDialog").close();
      publishTarget = null;
      completenessDraft = null;
      $("#publishCompleteness").hidden = true;
      await Promise.all([loadReadiness(), loadRules(), loadModels()]);
      state("Version publiée et journalisée.");
    } catch (error) {
      state(error?.message || "Publication impossible.", true);
    }
  }

  async function loadRules() {
    try {
      rules = await api.apiGet("/api/v1/governance/rules");
      renderRuleList();
    } catch (error) {
      $("#businessRuleList").innerHTML = `<div class="priority-empty">${e(error?.message || "Règles indisponibles.")}</div>`;
    }
  }

  function renderRuleList() {
    const search = $("#ruleSearch")?.value.trim().toLowerCase() || "";
    const status = $("#ruleStatusFilter")?.value || "";
    const visible = rules.filter((item) => {
      if (status && String(item.statut || "").toUpperCase() !== status) return false;
      if (!search) return true;
      return [item.logical_code, item.libelle, item.famille, item.version]
        .filter(Boolean).join(" ").toLowerCase().includes(search);
    });

    $("#businessRuleList").innerHTML = visible.length
      ? visible.map((item) => `
          <button class="institutional-list-row ${selectedRule?.id === item.id ? "active" : ""}" type="button" data-rule-id="${e(item.id)}">
            <span class="rule-icon"><i data-lucide="braces"></i></span>
            <div><strong>${e(item.logical_code)}</strong><small>${e(item.libelle || "—")} · v${e(item.version || "—")}</small></div>
            <span class="inst-status ${String(item.statut || "").toLowerCase()}">${e(item.statut || "—")}</span>
            <i data-lucide="chevron-right"></i>
          </button>
        `).join("")
      : `<div class="priority-empty">Aucune règle.</div>`;

    $$("[data-rule-id]").forEach((button) => {
      button.onclick = () => {
        selectedRule = rules.find((x) => String(x.id) === String(button.dataset.ruleId));
        renderRuleList();
        renderRuleDetail();
      };
    });
    icons();
  }

  function renderRuleDetail() {
    const node = $("#businessRuleDetail");
    if (!selectedRule) {
      node.innerHTML = `<div class="priority-empty">Sélectionnez une version de règle.</div>`;
      return;
    }

    const draft = String(selectedRule.statut || "").toUpperCase() === "BROUILLON";
    const published = String(selectedRule.statut || "").toUpperCase() === "PUBLIE";

    node.innerHTML = `
      <header>
        <div><p class="eyebrow">${e(selectedRule.famille || "RÈGLE")}</p><h2>${e(selectedRule.logical_code)}</h2><p>${e(selectedRule.libelle || "—")}</p></div>
        <span class="inst-status ${String(selectedRule.statut || "").toLowerCase()}">${e(selectedRule.statut || "—")}</span>
      </header>
      <div class="rule-detail-body">
        <div class="cert-info-grid">
          <div class="cert-info"><small>Version</small><strong>${e(selectedRule.version || "—")}</strong></div>
          <div class="cert-info"><small>Code physique</small><strong>${e(selectedRule.code || "—")}</strong></div>
          <div class="cert-info"><small>Début d’effet</small><strong>${e(selectedRule.date_debut_effet || "—")}</strong></div>
          <div class="cert-info"><small>Approbation</small><strong>${e(selectedRule.reference_approbation || "—")}</strong></div>
        </div>
        <label class="json-editor"><span>Paramètres JSON</span><textarea id="selectedRuleJson" rows="14" ${draft ? "" : "readonly"}>${e(JSON.stringify(selectedRule.parametres || {}, null, 2))}</textarea></label>
        <div class="institutional-actions no-pad-actions">
          ${draft && has("GOUVERNANCE.ADMINISTRER_REGLES") ? `<button class="btn btn-outline-secondary app-btn" id="saveSelectedRule" type="button"><i data-lucide="save"></i>Enregistrer</button><button class="btn btn-primary app-btn" id="publishSelectedRule" type="button"><i data-lucide="rocket"></i>Publier</button>` : ""}
          ${published && has("GOUVERNANCE.ADMINISTRER_REGLES") ? `<button class="btn btn-outline-secondary app-btn" id="cloneSelectedRule" type="button"><i data-lucide="copy-plus"></i>Nouvelle version</button>` : ""}
        </div>
      </div>
    `;

    $("#saveSelectedRule")?.addEventListener("click", async () => {
      try {
        const params = JSON.parse($("#selectedRuleJson").value);
        selectedRule = await api.apiPatch(
          `/api/v1/governance/rules/${selectedRule.id}`,
          { parametres: params }
        );
        await loadRules();
        state("Brouillon mis à jour.");
      } catch (error) {
        state(error?.message || "Mise à jour impossible.", true);
      }
    });

    $("#publishSelectedRule")?.addEventListener("click", () => openPublish("rule", selectedRule));
    $("#cloneSelectedRule")?.addEventListener("click", () => openRuleDialog(selectedRule));
    icons();
  }

  function openRuleDialog(source = null) {
    cloneSourceRule = source;
    $("#ruleDialogTitle").textContent = source ? "Nouvelle version" : "Nouvelle règle";
    $("#ruleCode").value = source?.logical_code || "";
    $("#ruleCode").disabled = Boolean(source);
    $("#ruleVersion").value = "";
    $("#ruleFamily").value = source?.famille || "";
    $("#ruleLabel").value = source?.libelle || "";
    $("#ruleDescription").value = source?.description || "";
    $("#ruleParams").value = JSON.stringify(source?.parametres || {}, null, 2);
    $("#ruleDialog").showModal();
    icons();
  }

  async function saveRuleDialog(event) {
    event.preventDefault();
    try {
      let created;
      if (cloneSourceRule) {
        created = await api.apiPost(
          `/api/v1/governance/rules/${cloneSourceRule.id}/clone`,
          {
            version: $("#ruleVersion").value.trim(),
            libelle: $("#ruleLabel").value.trim() || null,
            date_debut_effet: null,
          }
        );
        created = await api.apiPatch(
          `/api/v1/governance/rules/${created.id}`,
          {
            famille: $("#ruleFamily").value.trim() || null,
            description: $("#ruleDescription").value.trim() || null,
            parametres: JSON.parse($("#ruleParams").value || "{}"),
          }
        );
      } else {
        created = await api.apiPost("/api/v1/governance/rules", {
          logical_code: $("#ruleCode").value.trim(),
          famille: $("#ruleFamily").value.trim() || null,
          libelle: $("#ruleLabel").value.trim(),
          description: $("#ruleDescription").value.trim() || null,
          version: $("#ruleVersion").value.trim(),
          parametres: JSON.parse($("#ruleParams").value || "{}"),
          date_debut_effet: null,
        });
      }

      $("#ruleDialog").close();
      $("#ruleCode").disabled = false;
      cloneSourceRule = null;
      selectedRule = created;
      await loadRules();
      renderRuleDetail();
      state("Brouillon de règle créé.");
    } catch (error) {
      state(error?.message || "Création impossible.", true);
    }
  }

  async function loadModels() {
    try {
      const p = new URLSearchParams();
      if ($("#scoringObjectFilter")?.value) p.set("objet_evalue", $("#scoringObjectFilter").value);
      if ($("#scoringStatusFilter")?.value) p.set("statut", $("#scoringStatusFilter").value);
      models = await api.apiGet(`/api/v1/scoring/models${p.toString() ? `?${p}` : ""}`);
      renderModelList();
    } catch (error) {
      $("#scoringModelList").innerHTML = `<div class="priority-empty">${e(error?.message || "Modèles indisponibles.")}</div>`;
    }
  }

  function renderModelList() {
    $("#scoringModelList").innerHTML = models.length
      ? models.map((item) => `
          <button class="institutional-list-row ${selectedModel?.id === item.id ? "active" : ""}" type="button" data-model-id="${e(item.id)}">
            <span class="rule-icon"><i data-lucide="calculator"></i></span>
            <div><strong>${e(item.code || "Modèle")}</strong><small>${e(item.objet_evalue || "—")} · v${e(item.version || "—")}</small></div>
            <span class="inst-status ${String(item.statut || "").toLowerCase()}">${e(item.statut || "—")}</span>
            <i data-lucide="chevron-right"></i>
          </button>
        `).join("")
      : `<div class="priority-empty">Aucun modèle.</div>`;

    $$("[data-model-id]").forEach((button) => {
      button.onclick = async () => {
        selectedModel = models.find((x) => String(x.id) === String(button.dataset.modelId));
        await loadSelectedModel();
        renderModelList();
      };
    });
    icons();
  }

  async function loadSelectedModel() {
    if (!selectedModel) return;
    try {
      selectedModel = await api.apiGet(`/api/v1/scoring/models/${selectedModel.id}`);
      selectedWeights = await api.apiGet(`/api/v1/scoring/models/${selectedModel.id}/weights`);
      renderModelDetail();
    } catch (error) {
      state(error?.message || "Modèle indisponible.", true);
    }
  }

  function renderModelDetail() {
    const node = $("#scoringModelDetail");
    if (!selectedModel) {
      node.innerHTML = `<div class="priority-empty">Sélectionnez ou créez un modèle.</div>`;
      return;
    }

    const draft = String(selectedModel.statut || "").toUpperCase() === "BROUILLON";
    const infcDraft = draft && selectedModel.objet_evalue === "INFC";

    node.innerHTML = `
      <header>
        <div><p class="eyebrow">${e(selectedModel.objet_evalue || "SCORING")}</p><h2>${e(selectedModel.code || "Modèle")}</h2><p>${e(selectedModel.libelle || "—")}</p></div>
        <span class="inst-status ${String(selectedModel.statut || "").toLowerCase()}">${e(selectedModel.statut || "—")}</span>
      </header>
      <div class="rule-detail-body">
        <div class="cert-info-grid">
          <div class="cert-info"><small>Version</small><strong>${e(selectedModel.version || "—")}</strong></div>
          <div class="cert-info"><small>Mode</small><strong>${e(selectedModel.regle_calcul?.calculation_mode || "—")}</strong></div>
          <div class="cert-info"><small>Pondérations</small><strong>${e(selectedModel.ponderations_count || 0)}</strong></div>
          <div class="cert-info"><small>Total</small><strong>${e(selectedModel.total_ponderation || 0)}</strong></div>
        </div>

        <label class="json-editor"><span>Règle de calcul JSON</span><textarea id="selectedModelRule" rows="13" ${draft ? "" : "readonly"}>${e(JSON.stringify(selectedModel.regle_calcul || {}, null, 2))}</textarea></label>

        <section class="weights-admin">
          <div class="weights-admin-head">
            <div><strong>Pondérations / domaines</strong><small>Modifiables sur brouillon.</small></div>
            <div class="weights-buttons">
              ${infcDraft && has("SCORING.ADMINISTRER_MODELE") ? `<button class="btn btn-outline-secondary app-btn" id="loadInfcWeights" type="button"><i data-lucide="layers-3"></i>6 domaines INFC</button>` : ""}
              ${draft && has("SCORING.ADMINISTRER_MODELE") ? `<button class="btn btn-outline-secondary app-btn" id="addWeight" type="button"><i data-lucide="plus"></i>Ajouter</button>` : ""}
            </div>
          </div>
          <div class="weights-list">
            ${selectedWeights.length ? selectedWeights.map((w) => `
              <article class="weight-real-row">
                <div><strong>${e(w.domaine || "Domaine")}</strong><small>${e(w.statut || "—")}</small></div>
                <b>${e(w.valeur ?? "—")}</b>
                ${draft && String(w.statut || "").toUpperCase() !== "INACTIF" ? `<button class="remove-requirement" type="button" data-deactivate-weight="${e(w.id)}"><i data-lucide="ban"></i></button>` : ""}
              </article>
            `).join("") : `<div class="priority-empty compact">Aucune pondération.</div>`}
          </div>
        </section>

        <div class="institutional-actions no-pad-actions">
          ${draft && has("SCORING.ADMINISTRER_MODELE") ? `<button class="btn btn-outline-secondary app-btn" id="saveModelRule" type="button"><i data-lucide="save"></i>Enregistrer</button><button class="btn btn-primary app-btn" id="publishModel" type="button"><i data-lucide="rocket"></i>Publier</button>` : ""}
        </div>
      </div>
    `;

    $("#saveModelRule")?.addEventListener("click", async () => {
      try {
        selectedModel = await api.apiPatch(
          `/api/v1/scoring/models/${selectedModel.id}`,
          { regle_calcul: JSON.parse($("#selectedModelRule").value) }
        );
        await loadModels();
        renderModelDetail();
        state("Règle de calcul mise à jour.");
      } catch (error) {
        state(error?.message || "Mise à jour impossible.", true);
      }
    });

    $("#publishModel")?.addEventListener("click", () => openPublish("model", selectedModel));
    $("#addWeight")?.addEventListener("click", () => {
      $("#weightDomain").value = "";
      $("#weightValue").value = "";
      $("#weightDialog").showModal();
      icons();
    });
    $("#loadInfcWeights")?.addEventListener("click", loadDocumentedInfcWeights);

    $$("[data-deactivate-weight]").forEach((button) => {
      button.onclick = async () => {
        try {
          await api.apiPost(
            `/api/v1/scoring/models/${selectedModel.id}/weights/${button.dataset.deactivateWeight}/deactivate`,
            {}
          );
          await loadSelectedModel();
          state("Pondération désactivée.");
        } catch (error) {
          state(error?.message || "Désactivation impossible.", true);
        }
      };
    });
    icons();
  }

  function openModelDialog(classificationPreset = false) {
    $("#modelObject").value = "CLASSIFICATION_ENTREPRISE";
    $("#modelCode").value = classificationPreset ? "CLASSIFICATION_ENTREPRISE" : "";
    $("#modelVersion").value = "1.0";
    $("#modelLabel").value = classificationPreset ? "Classification globale des entreprises" : "";
    $("#modelDescription").value = classificationPreset
      ? "Référentiel RM-22 à RM-24 : Conforme, À surveiller, Non conforme."
      : "";
    $("#modelMode").value = "DIRECT_SCORE";
    $("#modelRounding").value = "2";
    $("#modelScoreMin").value = "0";
    $("#modelScoreMax").value = "100";
    $("#modelIntervals").value = classificationPreset
      ? JSON.stringify([
          { code: "CONFORME", min: 85 },
          { code: "A_SURVEILLER", min: 60 },
          { code: "NON_CONFORME", default: true },
        ], null, 2)
      : "[]";
    $("#modelDialog").showModal();
    icons();
  }

  async function createModel(event) {
    event.preventDefault();
    try {
      const objectType = $("#modelObject").value;
      const mode = $("#modelMode").value;
      const intervals = JSON.parse($("#modelIntervals").value || "[]");
      const rule = {
        calculation_mode: mode,
        rounding: Number($("#modelRounding").value || 2),
        score_min: Number($("#modelScoreMin").value || 0),
        score_max: Number($("#modelScoreMax").value || 100),
      };
      if (mode !== "DIRECT_SCORE") rule.missing_policy = "REJECT";
      if (objectType === "CLASSIFICATION_ENTREPRISE") rule.classes = intervals;
      else if (intervals.length) rule.levels = intervals;

      selectedModel = await api.apiPost("/api/v1/scoring/models", {
        code: $("#modelCode").value.trim(),
        libelle: $("#modelLabel").value.trim(),
        version: $("#modelVersion").value.trim(),
        objet_evalue: objectType,
        description: $("#modelDescription").value.trim() || null,
        date_debut_validite: null,
        date_fin_validite: null,
        regle_calcul: rule,
      });

      $("#modelDialog").close();
      await loadModels();
      await loadSelectedModel();
      state("Brouillon de modèle créé.");
    } catch (error) {
      state(error?.message || "Création impossible.", true);
    }
  }

  async function addWeight(event) {
    event.preventDefault();
    if (!selectedModel) return;
    try {
      await api.apiPost(`/api/v1/scoring/models/${selectedModel.id}/weights`, {
        domaine: $("#weightDomain").value.trim(),
        valeur: Number($("#weightValue").value),
        periode_debut: null,
        periode_fin: null,
        statut: "ACTIF",
      });
      $("#weightDialog").close();
      await loadSelectedModel();
      state("Pondération ajoutée.");
    } catch (error) {
      state(error?.message || "Ajout impossible.", true);
    }
  }

  async function loadDocumentedInfcWeights() {
    const values = [
      ["AUTHENTICITE", 20],
      ["VALIDITE", 20],
      ["MAINTIEN", 20],
      ["MAITRISE_DOCUMENTAIRE", 15],
      ["TRACABILITE_MAITRISE_OPERATIONNELLE", 15],
      ["SUIVI_RENOUVELLEMENT", 10],
    ];
    const existing = new Set(
      selectedWeights
        .filter((x) => String(x.statut || "").toUpperCase() !== "INACTIF")
        .map((x) => String(x.domaine || "").toUpperCase())
    );

    try {
      for (const [domaine, valeur] of values) {
        if (existing.has(domaine)) continue;
        await api.apiPost(`/api/v1/scoring/models/${selectedModel.id}/weights`, {
          domaine,
          valeur,
          periode_debut: null,
          periode_fin: null,
          statut: "ACTIF",
        });
      }
      await loadSelectedModel();
      state("Six domaines INFC documentés ajoutés au brouillon. La formule et le mapping numérique des niveaux restent à approuver avant publication définitive.");
    } catch (error) {
      state(error?.message || "Chargement impossible.", true);
    }
  }

  function switchTab(tab) {
    $$("[data-inst-tab]").forEach((button) => {
      button.classList.toggle("active", button.dataset.instTab === tab);
    });
    $("#completenessTab").hidden = tab !== "completeness";
    $("#rulesTab").hidden = tab !== "rules";
    $("#scoringTab").hidden = tab !== "scoring";
  }

  function bind() {
    $("#addFieldRequirement").onclick = () => {
      fieldReqs.push({ id: crypto.randomUUID(), label: "", fields: [], match: "ALL" });
      renderRequirements();
    };
    $("#addCountRequirement").onclick = () => {
      countReqs.push({
        id: crypto.randomUUID(),
        label: "",
        resource: catalog.count_resources?.[0]?.code || "DOCUMENTS",
        minimum: 1,
      });
      renderRequirements();
    };

    $("#validateCompleteness").onclick = validateCompleteness;
    $("#saveCompletenessDraft").onclick = createCompletenessDraft;
    $("#publishCompleteness").onclick = () => {
      if (completenessDraft) openPublish("rule", completenessDraft);
    };

    $("#newGenericRule").onclick = () => openRuleDialog();
    $("#ruleForm").onsubmit = saveRuleDialog;
    $("#publishForm").onsubmit = publish;

    $("#newScoringModel").onclick = () => openModelDialog(false);
    $("#prefillClassificationReference").onclick = () => openModelDialog(true);
    $("#modelForm").onsubmit = createModel;
    $("#weightForm").onsubmit = addWeight;

    $("#scoringObjectFilter").onchange = loadModels;
    $("#scoringStatusFilter").onchange = loadModels;
    $("#ruleStatusFilter").onchange = renderRuleList;
    $("#ruleSearch").oninput = () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(renderRuleList, 200);
    };

    $("#refreshInstitutional").onclick = async (event) => {
      try {
        await run(
          () => Promise.all([loadReadiness(), loadRules(), loadModels()]),
          { button: event.currentTarget, title: "Paramétrage institutionnel", message: "Actualisation" }
        );
      } catch (error) {
        state(error?.message || "Actualisation impossible.", true);
      }
    };

    $$("[data-inst-tab]").forEach((button) => {
      button.onclick = () => switchTab(button.dataset.instTab);
    });

    $$("[data-close-inst-dialog]").forEach((button) => {
      button.onclick = () => document.getElementById(button.dataset.closeInstDialog)?.close();
    });
  }

  try {
    user = await api.apiGet("/api/v1/me");
    if (!has("GOUVERNANCE.LIRE")) {
      state("Le compte courant ne possède pas GOUVERNANCE.LIRE.", true);
      return;
    }

    bind();
    await Promise.all([loadReadiness(), loadCatalog(), loadRules(), loadModels()]);
    renderRequirements();
  } catch (error) {
    state(error?.message || "Erreur de chargement.", true);
  }

  icons();
})();
