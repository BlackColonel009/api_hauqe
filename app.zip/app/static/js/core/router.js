import { APP_CONFIG } from "./config.js?v=20260731-1";
import { hasAccessToken } from "./api.js";

const routes = Object.freeze({
  dashboard: { view: "/views/dashboard", script: "/static/js/app.js?v=20260901-1", title: "Tableau de bord" },
  alertes: { view: "/views/alertes", script: "/static/js/alertes.js?v=20260901-1", title: "Centre des alertes" },
  echeances: { view: "/views/echeances", script: "/static/js/echeances.js?v=20260901-1", title: "Calendrier des échéances" },
  entreprises: { view: "/views/entreprises", script: "/static/js/entreprises.js?v=20260914-1", title: "Entreprises certifiées" },
  "entreprise-detail": { view: "/views/entreprise-detail", script: "/static/js/entreprise-detail.js?v=20260730-1", title: "Dossier entreprise" },
  "entreprise-form": { view: "/views/entreprise-form", script: "/static/js/entreprise-form.js?v=20260730-1", title: "Entreprise — formulaire" },
  certifications: { view: "/views/certifications", script: "/static/js/certifications.js", title: "Certifications" },
  "certification-detail": { view: "/views/certification-detail", script: "/static/js/certification-detail.js?v=20260730-4", title: "Dossier certification" },
  "certification-form": { view: "/views/certification-form", script: "/static/js/certification-form.js", title: "Certification — formulaire" },
  organismes: { view: "/views/organismes", script: "/static/js/organismes.js", title: "Organismes certificateurs" },
  "organisme-detail": { view: "/views/organisme-detail", script: "/static/js/organisme-detail.js", title: "Dossier organisme" },
  "organisme-form": { view: "/views/organisme-form", script: "/static/js/organisme-form.js", title: "Organisme — formulaire" },
  collectes: { view: "/views/collectes", script: "/static/js/collectes.js", title: "Collectes & contrôles" },
  "campagnes-collecte": { view: "/views/campagnes-collecte", script: "/static/js/campagnes-collecte.js?v=20260903-1", title: "Gestion des campagnes" },
  "collecte-form": { view: "/views/collecte-form", script: "/static/js/collecte-form.js?v=20260902-1", title: "Fiche de collecte" },
  validations: { view: "/views/validations", script: "/static/js/validations.js", title: "Validation des collectes" },
  "validation-detail": { view: "/views/validation-detail", script: "/static/js/validation-detail.js", title: "Validation hiérarchisée" },
  controle: { view: "/views/controle", script: "/static/js/controle.js", title: "Grille de contrôle" },
  "controle-detail": { view: "/views/controle-detail", script: "/static/js/controle-detail.js", title: "Contrôle FUCCS" },
  scoring: { view: "/views/scoring", script: "/static/js/scoring.js", title: "Scoring et conformité" },
  rapports: { view: "/views/rapports", script: "/static/js/rapports.js?v=20260730-3", title: "Rapports et exports" },
  utilisateurs: { view: "/views/utilisateurs", script: "/static/js/utilisateurs.js", title: "Gestion des utilisateurs" },
  referentiels: { view: "/views/referentiels", script: "/static/js/referentiels.js?v=20260730-2", title: "Référentiels" },
  "zones-administratives": { view: "/views/zones-administratives", script: "/static/js/zones-administratives.js", title: "Zones administratives" },
  "regles-codification": { view: "/views/regles-codification", script: "/static/js/regles-codification.js?v=20260730-3", title: "Règles et codification" },
  "journal-audit": { view: "/views/journal-audit", script: "/static/js/journal-audit.js?v=20260730-2", title: "Journal d’audit" },
  connexion: { view: "/views/connexion", script: "/static/js/connexion.js", title: "Connexion" },
  "mot-de-passe-oublie": { view: "/views/mot-de-passe-oublie", script: "/static/js/mot-de-passe-oublie.js?v=20260731-1", title: "Mot de passe oublié" },
  profil: { view: "/views/profil", script: "/static/js/profil.js?v=20260914-1", title: "Mon profil" },
  verifications: { view: "/views/verifications", script: "/static/js/verifications.js", title: "Vérification documentaire" },
  "verification-detail": { view: "/views/verification-detail", script: "/static/js/verification-detail.js", title: "Dossier de vérification" },
  integrations: { view: "/views/integrations", script: "/static/js/integrations.js", title: "Intégration BNEC" },
  "integration-detail": { view: "/views/integration-detail", script: "/static/js/integration-detail.js", title: "Dossier d’intégration BNEC" },
  infc: { view: "/views/infc", script: "/static/js/infc.js", title: "INFC" },
  "classement-sncc": { view: "/views/classement-sncc", script: "/static/js/classement-sncc.js?v=20260730-3", title: "Classement SNCC" },
  veille: { view: "/views/veille", script: "/static/js/veille.js?v=20260730-2", title: "Cellule de veille" },
  decisions: { view: "/views/operations-stage13", script: "/static/js/operations-stage13.js", title: "Décisions et plans d’action" },
  "mises-a-jour": { view: "/views/operations-stage13", script: "/static/js/operations-stage13.js", title: "Mises à jour BNEC" },
  documents: { view: "/views/operations-stage13", script: "/static/js/operations-stage13.js", title: "Gestion documentaire" },
  incidents: { view: "/views/governance-module", script: "/static/js/governance-modules.js", title: "Incidents" },
  "amelioration-continue": { view: "/views/governance-module", script: "/static/js/governance-modules.js", title: "Amélioration continue" },
  sauvegardes: { view: "/views/sauvegardes", script: "/static/js/sauvegardes.js?v=20260730-1", title: "Sauvegardes et restaurations" },
  "qualite-donnees": { view: "/views/qualite-donnees", script: "/static/js/qualite-donnees.js?v=20260730-1", title: "Qualité des données" },
  publications: { view: "/views/publications", script: "/static/js/publications.js?v=20260730-1", title: "Demandes de publication" },
  "echanges-organismes": { view: "/views/operations-stage13", script: "/static/js/operations-stage13.js", title: "Échanges avec les organismes" },
  "tableau-tactique": { view: "/views/dashboard-advanced", script: "/static/js/dashboard-advanced.js", title: "Tableau de bord tactique" },
  "tableau-strategique": { view: "/views/dashboard-advanced", script: "/static/js/dashboard-advanced.js", title: "Tableau de bord stratégique" },
  "tableau-annuel": { view: "/views/dashboard-advanced", script: "/static/js/dashboard-advanced.js", title: "Tableau de bord annuel" },
  barometre: { view: "/views/dashboard-advanced", script: "/static/js/dashboard-advanced.js", title: "Baromètre national" },
  public: { view: "/views/dashboard-advanced", script: "/static/js/dashboard-advanced.js", title: "Tableau de bord public" },
});

let currentRoute = null;
let latestNavigationId = 0;

function routeName() {
  const parts = location.hash.replace(/^#\/?/, "").split("/");
  parts[0] = parts[0].split("?")[0];
  const name = parts[0] === "entreprises" && ["nouveau", "modifier"].includes(parts[1]) ? "entreprise-form" : parts[0] === "entreprises" && parts[1] ? "entreprise-detail" : parts[0] === "certifications" && ["nouveau", "modifier"].includes(parts[1]) ? "certification-form" : parts[0] === "certifications" && parts[1] ? "certification-detail" : parts[0] === "organismes" && ["nouveau", "modifier"].includes(parts[1]) ? "organisme-form" : parts[0] === "organismes" && parts[1] ? "organisme-detail" : parts[0] === "collectes" && ["nouveau", "modifier"].includes(parts[1]) ? "collecte-form" : parts[0] === "verifications" && parts[1] ? "verification-detail" : parts[0] === "validations" && parts[1] ? "validation-detail" : parts[0] === "integrations" && parts[1] ? "integration-detail" : parts[0] === "controle" && parts[1] ? "controle-detail" : parts[0] === "tableaux-de-bord" && parts[1] ? `tableau-${parts[1]}` : parts[0];
  return routes[name] ? name : APP_CONFIG.defaultRoute;
}

function setActiveRoute(name) {
  document.querySelectorAll("[data-route]").forEach((link) => link.classList.toggle("active", link.dataset.route === name));
}

function extractContent(html) {
  const documentFragment = new DOMParser().parseFromString(html, "text/html");
  const page = documentFragment.querySelector(".page-content");
  if (!page) throw new Error("Contenu de page introuvable");
  return page.outerHTML;
}

function executePageScript(src) {
  document.querySelectorAll("script[data-page-script]").forEach((script) => script.remove());
  return new Promise((resolve, reject) => {
    const script = document.createElement("script");
    // Les routes possèdent parfois déjà un paramètre de version. Ajouter un
    // second `?` donne une URL ambiguë et peut laisser le navigateur servir un
    // script précédent. Le séparateur doit toujours être correct.
    const separator = src.includes("?") ? "&" : "?";
    script.src = `${src}${separator}load=${Date.now()}`;
    script.dataset.pageScript = "true";
    script.onload = resolve;
    script.onerror = reject;
    document.body.appendChild(script);
  });
}


const PUBLIC_ROUTES = new Set([
  "connexion",
  "mot-de-passe-oublie",
  "public",
]);

function enforceRouteAuthentication(name) {
  if (PUBLIC_ROUTES.has(name)) return true;

  if (!hasAccessToken()) {
    sessionStorage.setItem(
      "hauqe-return-after-login",
      location.hash || "#/dashboard"
    );
    location.hash = "#/connexion";
    return false;
  }

  return true;
}

function applyAuthRouteClass(name) {
  document.body.classList.toggle(
    "auth-route-active",
    ["connexion", "mot-de-passe-oublie"].includes(name)
  );
}

export async function navigate(options = {}) {
  const navigationId = ++latestNavigationId;
  const {
    silent = false,
    preserveScroll = false,
  } = options && !options.type ? options : {};
  const loadingStartedAt = performance.now();
  const name = routeName();

  if (!enforceRouteAuthentication(name)) {
    return;
  }

  applyAuthRouteClass(name);

  const route = routes[name];
  const content = document.querySelector("#pageContent");
  const loading = document.querySelector("#routeLoading");
  const error = document.querySelector("#routeError");
  const previousScroll = window.scrollY;
  if (!silent) loading.hidden = false;
  error.hidden = true;
  try {
    const response = await fetch(route.view, {
      cache: "no-store",
      headers: { "X-Requested-With": "HAUQE-SPA" },
    });
    if (!response.ok) throw new Error(`Erreur ${response.status}`);
    const html = await response.text();
    // Une navigation plus récente a gagné : cette réponse ne doit surtout pas
    // remettre une ancienne page ou un ancien script dans le navigateur.
    if (navigationId !== latestNavigationId) return;
    content.innerHTML = extractContent(html);
    await executePageScript(route.script);
    if (navigationId !== latestNavigationId) return;
    window.dispatchEvent(new CustomEvent("hauqe:page-ready", {
      detail: { route: name, refresh: silent },
    }));
    currentRoute = name;
    setActiveRoute(name);
    document.title = `${APP_CONFIG.appName} — ${route.title}`;
    document.querySelector("#sidebar").classList.remove("open");
    window.scrollTo({
      top: preserveScroll ? previousScroll : 0,
      behavior: "instant",
    });
    if (window.lucide) window.lucide.createIcons({ attrs: { "stroke-width": 1.8 } });
  } catch (err) {
    console.error(err); content.innerHTML = ""; error.hidden = false;
  } finally {
    if (!silent) {
      const remaining = 420 - (performance.now() - loadingStartedAt);
      if (remaining > 0) {
        await new Promise((resolve) => setTimeout(resolve, remaining));
      }
      loading.hidden = true;
    }
  }
}

export function initRouter() {
  window.addEventListener("hashchange", () => navigate());
  document.querySelector("#retryRoute").addEventListener("click", () => navigate());
  if (!location.hash) location.replace(`#/${APP_CONFIG.defaultRoute}`); else navigate();
}

export function getCurrentRoute() { return currentRoute; }

export function refreshCurrentRoute() {
  return navigate({ silent: true, preserveScroll: true });
}
